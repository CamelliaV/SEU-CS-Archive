package seu.assignment.scenario3;

class JiuLongHuRestaurant extends AbstractPlatform {


	private String name = "JiuLongHuRestaurant";

	@Override
	public String toString() {
		return this.name;
	}
}