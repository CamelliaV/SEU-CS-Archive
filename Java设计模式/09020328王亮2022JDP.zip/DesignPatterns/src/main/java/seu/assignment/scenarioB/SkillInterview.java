package seu.assignment.scenarioB;

/**
 * @ClassName: SkillInterview
 * @Description: java类描述
 * @Author: 11609
 * @Date: 2022/11/24 18:13:27
 * @Input:
 * @Output:
 */
class SkillInterview extends InterviewState {
}