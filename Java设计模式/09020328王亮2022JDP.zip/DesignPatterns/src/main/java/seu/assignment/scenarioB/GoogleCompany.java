package seu.assignment.scenarioB;

/**
 * @ClassName: GoogleCompany
 * @Description: java类描述
 * @Author: 11609
 * @Date: 2022/11/24 18:09:08
 * @Input:
 * @Output:
 */
class GoogleCompany extends ProxyCompany {
}