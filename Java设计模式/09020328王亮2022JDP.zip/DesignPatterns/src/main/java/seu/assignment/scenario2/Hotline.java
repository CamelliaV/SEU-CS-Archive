package seu.assignment.scenario2;

public interface Hotline {
	void negotiate(Participant a, Participant b);
}
