package seu.assignment.scenario3;

class Eleme extends AbstractPlatform {
	private String name = "Eleme";

	@Override
	public String toString() {
		return this.name;
	}
}