package seu.assignment.scenario4;

class Cleaner extends Staff {
   @Override
   public void action() {
      System.out.println("-----------Staff: Cleaning handled");
   }
}