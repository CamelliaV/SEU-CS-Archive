package seu.assignment.scenario4;

class TaoBeiRestaurant extends AbstractRestaurant {
   @Override
   public void dinner() {
      System.out.println("-----------Dinner At TaoBeiRestaurant");
   }
}