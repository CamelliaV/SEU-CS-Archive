package seu.assignment.scenario4;

public interface Command {
	void execute(Staff staff);
}
