package seu.assignment.scenario4;

class TaoNanRestaurant extends AbstractRestaurant {
   @Override
   public void dinner() {
      System.out.println("-----------Dinner At TaoNanRestaurant");
   }
}