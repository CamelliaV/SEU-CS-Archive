package seu.assignment.scenarioB;

/**
 * @ClassName: FirstInterview
 * @Description: java类描述
 * @Author: 11609
 * @Date: 2022/11/24 18:13:20
 * @Input:
 * @Output:
 */
class FirstInterview extends InterviewState {
}