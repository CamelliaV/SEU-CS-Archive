package seu.assignment.scenario4;

class Reception extends Staff {
   @Override
   public void action() {
      System.out.println("-----------Staff: Payment handled");
   }
}