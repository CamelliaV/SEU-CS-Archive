package seu.assignment.scenarioB;

/**
 * @ClassName: AmazonCompany
 * @Description: java类描述
 * @Author: 11609
 * @Date: 2022/11/24 18:09:20
 * @Input:
 * @Output:
 */
class AmazonCompany extends ProxyCompany {
}