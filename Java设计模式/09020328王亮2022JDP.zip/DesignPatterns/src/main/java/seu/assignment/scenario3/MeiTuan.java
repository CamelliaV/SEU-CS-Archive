package seu.assignment.scenario3;

class MeiTuan extends AbstractPlatform {
	private String name = "MeiTuan";

	@Override
	public String toString() {
		return this.name;
	}
}