package seu.assignment.scenario2;

class NanJingDaJin extends Participant {
	@Override
	public void act() {
		System.out.println("------------NanJingDaJin: Response to service");
	}
}