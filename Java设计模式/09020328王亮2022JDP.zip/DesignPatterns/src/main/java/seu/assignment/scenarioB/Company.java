package seu.assignment.scenarioB;

public interface Company {
	Offer recruit(Candidate candidate);
}
