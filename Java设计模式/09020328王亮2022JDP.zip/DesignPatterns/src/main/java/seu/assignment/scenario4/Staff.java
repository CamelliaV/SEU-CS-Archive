package seu.assignment.scenario4;

abstract class Staff {
   private Integer id;

   public abstract void action();
}