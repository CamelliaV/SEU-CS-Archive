package seu.assignment.scenario4;

class MeiYuanRestaurant extends AbstractRestaurant {
   @Override
   public void dinner() {
      System.out.println("-----------Dinner At MeiYuanRestaurant");
   }
}