package seu.assignment.scenario4;

import java.util.Iterator;

public interface WindowStrategy {
	Iterator<Window> iterator();
}
