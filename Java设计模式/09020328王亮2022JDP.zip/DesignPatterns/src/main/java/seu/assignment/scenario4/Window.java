package seu.assignment.scenario4;

class Window {
   private Integer number;

   Window(Integer number) {
      this.number = number;
   }



   public Integer getNumber() {
      return number;
   }
}