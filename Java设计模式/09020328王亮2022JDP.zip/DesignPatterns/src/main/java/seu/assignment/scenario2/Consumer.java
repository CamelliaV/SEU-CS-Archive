package seu.assignment.scenario2;

class Consumer extends Participant {
	@Override
	public void act() {
		System.out.println("------------Consumer: Call for service");
	}
}