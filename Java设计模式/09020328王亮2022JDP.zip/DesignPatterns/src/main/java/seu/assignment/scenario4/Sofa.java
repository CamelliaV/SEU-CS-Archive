package seu.assignment.scenario4;

class Sofa extends Seat {
   private final String type = "Sofa";

   public Sofa(Integer number) {
      super(number);
   }
}