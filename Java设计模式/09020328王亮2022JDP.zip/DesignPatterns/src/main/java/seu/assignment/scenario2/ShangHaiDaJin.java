package seu.assignment.scenario2;

class ShangHaiDaJin extends Participant {
   @Override
   public void act() {
      System.out.println("------------ShangHaiDaJin: Response to service");

   }
}