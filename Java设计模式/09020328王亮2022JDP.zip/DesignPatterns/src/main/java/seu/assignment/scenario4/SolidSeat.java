package seu.assignment.scenario4;

class SolidSeat extends Seat {
   private final String type = "SolidSeat";

   public SolidSeat(Integer number) {
      super(number);
   }
}