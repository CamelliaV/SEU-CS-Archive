package seu.assignment.scenario4;

class SoftSeat extends Seat {
   private final String type = "SoftSeat";

   public SoftSeat(Integer number) {
      super(number);
   }
}