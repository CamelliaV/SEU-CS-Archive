package seu.assignment.scenario4;

public interface ConsumingStyle {
	void haveFruits();
	void haveVegetables();
	void haveMeats();
	void haveDrinks();
	String digest();
}
