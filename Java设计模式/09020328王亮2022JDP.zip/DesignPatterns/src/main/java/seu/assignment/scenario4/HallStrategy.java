package seu.assignment.scenario4;

public interface HallStrategy {
	void dinner();
}
