package seu.assignment.final_scenario;

class JingDongExpress {
   public void deliver() {
      System.out.println("京东派送中");
   }
}