package seu.assignment.final_scenario;

public interface Item {
	void accept(Colleague colleague);
	Double getPrice();

}
