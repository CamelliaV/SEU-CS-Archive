package seu.assignment.final_scenario;

public interface ConsumingProcess {
	void measureTemperature();
	void testAntigen();
	void consumeTablets();
	void consumePapers();
	String calm();
}
