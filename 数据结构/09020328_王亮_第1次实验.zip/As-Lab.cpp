//#include<iostream>
//#include<cmath>
//using namespace std;
//int main()
//{
//	cout << boolalpha;
//	for(int n = 1;n <= 50;n++)
//	{
//		cout << "n= " << n << " " << "n^2= " << pow(n, 2) << " " <<  "(2^n)/4= " << pow(2, n) / 4;
//		cout << " " << ((pow(n, 2) < (pow(2, n) / 4)) ? true : false) << endl;
//	}
//}